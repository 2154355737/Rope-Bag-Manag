package com.jieshengshequ.app;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  // 完全使用Capacitor默认配置，不进行任何自定义
}
