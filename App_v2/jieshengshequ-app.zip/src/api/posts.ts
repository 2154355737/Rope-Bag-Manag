import { http } from './client'

export async function getPosts(params?: { page?: number; pageSize?: number; tag?: string }) {
	const data = await http.get<{ list: any[]; total: number; page: number; page_size: number }>(`/posts`, params)
	return data
}

export async function getPost(id: number) {
	return http.get<any>(`/posts/${id}`)
}

export async function toggleLikePost(id: number) {
	// 后端是 POST /posts/{id}/like 并返回最新计数
	return http.post<{ like_count?: number }>(`/posts/${id}/like`)
}

export async function unlikePost(id: number) {
	return http.delete<{ like_count?: number }>(`/posts/${id}/like`)
}

export async function toggleBookmarkPost(id: number) {
	// 后端采用 POST/DELETE /posts/{id}/bookmark；做成幂等：先尝试 POST，失败再 DELETE
	try { return await http.post<{ favorite_count?: number }>(`/posts/${id}/bookmark`) } catch { return await http.delete<{ favorite_count?: number }>(`/posts/${id}/bookmark`) }
}

export async function reportPost(id: number) {
	return http.post(`/posts/${id}/report`, {})
}

// 状态查询
export async function getPostLikeStatus(id: number) {
	return http.get<{ liked: boolean }>(`/posts/${id}/like-status`)
}
export async function getPostBookmarkStatus(id: number) {
	return http.get<{ favorited: boolean }>(`/posts/${id}/bookmark-status`)
}

// 删除帖子
export async function deletePost(id: number) {
	return http.delete(`/posts/${id}`)
}

// 更新帖子状态
export async function updatePostStatus(id: number, status: string) {
	return http.put(`/posts/${id}/status`, { status })
}

// 更新帖子内容
export async function updatePost(id: number, data: {
	title?: string
	content?: string
	tags?: string[]
}) {
	return http.put(`/posts/${id}`, data)
} 