import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90",
        destructive:
          "bg-destructive text-destructive-foreground hover:bg-destructive/90",
        outline:
          "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
        secondary:
          "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",
        like: "text-muted-foreground hover:text-red-500 transition-colors hover:scale-105 active:scale-95",
        "like-active": "text-red-500 hover:text-red-600 transition-colors hover:scale-105 active:scale-95",
        bookmark: "text-muted-foreground hover:text-blue-500 transition-colors hover:scale-105 active:scale-95",
        "bookmark-active": "text-blue-500 hover:text-blue-600 transition-colors hover:scale-105 active:scale-95",
        share: "text-muted-foreground hover:text-green-500 transition-colors hover:scale-105 active:scale-95",
        report: "text-muted-foreground hover:text-orange-500 transition-colors hover:scale-105 active:scale-95",
        minimal: "text-muted-foreground hover:text-foreground transition-colors",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 rounded-md px-3",
        lg: "h-11 rounded-md px-8",
        icon: "h-10 w-10",
        xs: "h-8 rounded-md px-2",
        compact: "h-6 rounded px-1.5",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, onClick, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    
    // 自动处理点击后失焦，避免高亮残留
    const handleClick = React.useCallback((e: React.MouseEvent<HTMLButtonElement>) => {
      if (onClick) {
        onClick(e)
      }
      
      // 延迟失焦，确保点击事件先完成
      setTimeout(() => {
        // 检查元素是否仍然存在且可以失焦
        if (e.currentTarget && typeof e.currentTarget.blur === 'function') {
          try {
            e.currentTarget.blur()
          } catch (error) {
            // 忽略失焦错误，通常发生在元素已被卸载的情况下
            console.debug('Button blur failed (element may have been unmounted):', error)
          }
        }
      }, 0)
    }, [onClick])
    
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        onClick={asChild ? onClick : handleClick}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button, buttonVariants }